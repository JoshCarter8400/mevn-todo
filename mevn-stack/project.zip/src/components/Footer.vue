<template>
  <footer id="custom-footer">
    <span class="mr-4">&copy; 2021 Josh Carter</span>
    <span class="mr-4">Privacy</span>
    <span class="mr-4">Terms of Service</span>
  </footer>
</template>
